
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        table{
            border: 3px solid #FF7D61;
            background:#FF7D61;
            border-radius:5px;

        }
        thead{
            background:#76E1F6 ;
        }
    </style>
</head>
<body>
    <h2 style="color:#FF7D61;">Lista de reservas</h2>
    <table style="width:100%;">
        <thead>
            <tr>
                <td>Id</td>
                <td>Espacio</td>
                <td>Usuario</td>
                <td>Vehículo</td>
                <td>Fecha reserva</td>
                <td>Hora ingreso</td>
                <td>Hora salida</td>
                <td>Estado</td>
            </tr>

        </thead>
        <tbody>
            <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reserva->idreserva); ?></td>
                <td><?php echo e($reserva->nomespacio); ?></td>
                <td><?php echo e($reserva->nomusuario); ?></td>
                <td><?php echo e($reserva->nomvehiculo); ?></td>
                <td><?php echo e($reserva->fecha_reserva); ?></td>
                <td><?php echo e($reserva->fecha_ingreso); ?></td>
                <td><?php echo e($reserva->fecha_salida); ?></td>
                <?php if($reserva->estado=='1'): ?>
                <td><p style="padding:10px; background-color: #094E1E; width:100px; color:#fff; text-align:center; border-radius:5px;">En curso</p></td>
                <?php else: ?>
                <td><p style="padding:10px; background-color:#96240D;#FF4C4C; width:100px; color:#fff; text-align:center; border-radius:5px;">Terminado</p></td>
                <?php endif; ?>
                
                
                    
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH D:\xamp\htdocs\proyecto-parking\resources\views/admin/tablareservas.blade.php ENDPATH**/ ?>