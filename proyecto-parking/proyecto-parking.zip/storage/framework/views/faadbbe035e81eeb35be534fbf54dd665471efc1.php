<table class="table">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Espacio</th>
        <th scope="col">Usuario</th>
        <th scope="col">Vehiculo</th>
        <th scope="col">fecha de reserva</th>
        <th scope="col">Hora de ingreso</th>
        <th scope="col">Hora de salida</th>
        <th scope="col">Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resultadosFiltrarEspacio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadoFiltrarEspacio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
            <th scope="row"><?php echo e($resultadoFiltrarEspacio->idreserva); ?></th>
            
            <td><?php echo e($resultadoFiltrarEspacio->nomespacio); ?></td>
            <td><?php echo e($resultadoFiltrarEspacio->nomusuario); ?></td>
            <td><?php echo e($resultadoFiltrarEspacio->nomvehiculo); ?></td>
            <td><?php echo e($resultadoFiltrarEspacio->fecha_reserva); ?></td>
            <td><?php echo e($resultadoFiltrarEspacio->fecha_ingreso); ?></td>
            <td><?php echo e($resultadoFiltrarEspacio->fecha_salida); ?></td>
            <?php if($resultadoFiltrarEspacio->estado=='1'): ?>
                <td><p style="padding:10px; background-color:#4CFF57; width:100px; color:#fff; text-align:center; border-radius:5px;">En curso</p></td>
            <?php else: ?>
                <td><p style="padding:10px; background-color:#FF4C4C; width:100px; color:#fff; text-align:center; border-radius:5px;">Terminado</p></td>
            <?php endif; ?>
            
        
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </tbody>
    </table>  <?php /**PATH D:\xamp\htdocs\proyecto-parking\resources\views/admin/tablafiltrarespacioreservas.blade.php ENDPATH**/ ?>