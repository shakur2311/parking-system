
<?php $__env->startSection('content-nav'); ?>
<?php if(Auth::user()->role=="0"): ?>
        
        <li class="nav-item mb-3 mx-auto">
            <a class="" href="/admin/perfil"><img src="<?php echo e(URL::asset('static/img/usuarios/'.Auth::user()->img.'')); ?>" alt="" class="user-avatar-lg rounded-circle"></a>
        </li>
        <li class="nav-item mb-3 mx-auto">
            <h4 style="color:#fff; font-weight:bold;"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></h4>
        </li>
        <li class="nav-item mb-5 mx-auto">
            <p style="color:#fff; font-weight: italic;">Administrador</p>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="/"><i class="fa fa-fw fa-home mr-3" ></i>Inicio <span class="badge badge-success"></span></a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="" style="background: rgba(182, 119, 23 ,1); border-radius:10px;"><i class="fas fa-chart-line mr-3"></i>Dashboard <span class="badge badge-success"></span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/admin/vehiculos" ><i class="fa fa-fw fa-car mr-3"></i>Registros de vehículos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/admin/usuarios"><i class="fas fa-fw fa-user mr-3"></i>Registros de Usuarios</a>                             
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/admin/reservas"><i class="fas fa-fw fa-box mr-3"></i>Registros de reservas</a>                             
        </li>
        <li class="nav-item" style="bottom:0px;">
            <a class="nav-link" href="/logout"><i class="fas fa-power-off mr-3"></i>Cerrar Sesión</a>                           
        </li>
        
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-5 mb-7">
        <div class="col-md-12">
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Indicador 1: Volumen de tránsito</button>
                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Indicador 2: Número de espacios disponibles</button>
                    
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" style="padding:30px;">
                    <h3>Registro de Flujo vehicular</h3>
                    <table class="table table-striped text-center" >
                        <thead>
                            <tr>
                                <th>Horas</th>
                                <th>Flujo Vehicular</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>07:00-08:00</td>
                                <td><?php echo e($flujo_entrada_7_8 + $flujo_salida_7_8); ?></td>
                            </tr>
                            <tr>
                                <td>08:00-09:00</td>
                                <td><?php echo e($flujo_entrada_8_9 + $flujo_salida_8_9); ?></td>
                            </tr>
                            <tr>
                                <td>09:00-10:00</td>
                                <td><?php echo e($flujo_entrada_9_10 + $flujo_salida_9_10); ?></td>
                            </tr>
                            <tr>
                                <td>10:00-11:00</td>
                                <td><?php echo e($flujo_entrada_10_11 + $flujo_salida_10_11); ?></td>
                            </tr>
                            <tr>
                                <td>11:00-12:00</td>
                                <td><?php echo e($flujo_entrada_11_12 + $flujo_salida_11_12); ?></td>
                            </tr>
                            <tr>
                                <td>12:00-13:00</td>
                                <td><?php echo e($flujo_entrada_12_13 + $flujo_salida_12_13); ?></td>
                            </tr>
                            <tr>
                                <td>13:00-14:00</td>
                                <td><?php echo e($flujo_entrada_13_14 + $flujo_salida_13_14); ?></td>
                            </tr>
                            <tr>
                                <td>14:00-15:00</td>
                                <td><?php echo e($flujo_entrada_14_15 + $flujo_salida_14_15); ?></td>
                            </tr>
                            <tr>
                                <td>15:00-16:00</td>
                                <td><?php echo e($flujo_entrada_15_16 + $flujo_salida_15_16); ?></td>
                            </tr>
                            <tr>
                                <td>16:00-17:00</td>
                                <td><?php echo e($flujo_entrada_16_17 + $flujo_salida_16_17); ?></td>
                            </tr>
                            <tr>
                                <td>17:00-18:00</td>
                                <td><?php echo e($flujo_entrada_17_18 + $flujo_salida_17_18); ?></td>
                            </tr>
                            <tr>
                                <td>18:00-19:00</td>
                                <td><?php echo e($flujo_entrada_18_19 + $flujo_salida_18_19); ?></td>
                            </tr>
                            <tr>
                                <td>19:00-20:00</td>
                                <td><?php echo e($flujo_entrada_19_20 + $flujo_salida_19_20); ?></td>
                            </tr>
                            <tr>
                                <td>20:00-21:00</td>
                                <td><?php echo e($flujo_entrada_20_21 + $flujo_salida_20_21); ?></td>
                            </tr>
                            <tr>
                                <td>21:00-22:00</td>
                                <td><?php echo e($flujo_entrada_21_22 + $flujo_salida_21_22); ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <h3 style="text-align:center;" class="mt-5">Flujo Vehicular</h3>
                    <canvas id="hora_volumen_transito_chart"></canvas>
                    
                </div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" style="padding:30px;">
                    <h3>Registro de espacios disponibles</h3>
                    <table class="table table-striped text-center" >
                        <thead>
                            <tr>
                                <th>Horas</th>
                                <th>Espacio disponibles</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>07:00-08:00</td>
                                <td><?php echo e($numero_espacios_disponibles_7_8); ?></td>
                            </tr>
                            <tr>
                                <td>08:00-09:00</td>
                                <td><?php echo e($numero_espacios_disponibles_8_9); ?></td>
                            </tr>
                            <tr>
                                <td>09:00-10:00</td>
                                <td><?php echo e($numero_espacios_disponibles_9_10); ?></td>
                            </tr>
                            <tr>
                                <td>10:00-11:00</td>
                                <td><?php echo e($numero_espacios_disponibles_10_11); ?></td>
                            </tr>
                            <tr>
                                <td>11:00-12:00</td>
                                <td><?php echo e($numero_espacios_disponibles_11_12); ?></td>
                            </tr>
                            <tr>
                                <td>12:00-13:00</td>
                                <td><?php echo e($numero_espacios_disponibles_12_13); ?></td>
                            </tr>
                            <tr>
                                <td>13:00-14:00</td>
                                <td><?php echo e($numero_espacios_disponibles_13_14); ?></td>
                            </tr>
                            <tr>
                                <td>14:00-15:00</td>
                                <td><?php echo e($numero_espacios_disponibles_14_15); ?></td>
                            </tr>
                            <tr>
                                <td>15:00-16:00</td>
                                <td><?php echo e($numero_espacios_disponibles_15_16); ?></td>
                            </tr>
                            <tr>
                                <td>16:00-17:00</td>
                                <td><?php echo e($numero_espacios_disponibles_16_17); ?></td>
                            </tr>
                            <tr>
                                <td>17:00-18:00</td>
                                <td><?php echo e($numero_espacios_disponibles_17_18); ?></td>
                            </tr>
                            <tr>
                                <td>18:00-19:00</td>
                                <td><?php echo e($numero_espacios_disponibles_18_19); ?></td>
                            </tr>
                            <tr>
                                <td>19:00-20:00</td>
                                <td><?php echo e($numero_espacios_disponibles_19_20); ?></td>
                            </tr>
                            <tr>
                                <td>20:00-21:00</td>
                                <td><?php echo e($numero_espacios_disponibles_20_21); ?></td>
                            </tr>
                            <tr>
                                <td>21:00-22:00</td>
                                <td><?php echo e($numero_espacios_disponibles_21_22); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h3 style="text-align:center;" class="mt-5">Número de espacios disponibles por hora</h3>
                    <canvas id="hora_numero_espacios_disponibles_chart"></canvas>
                </div>
            
            </div>
        </div>
    </div>
    <div class="row mt-5 mb-5">
        <div class="col-md-4">
            <h3 style="text-align:center;">Número de reservas por fecha</h3>
            <canvas id="fecha_nreservas_chart" width="400" height="400"></canvas>
        </div>
        <div class="col-md-4">
            <h3 style="text-align:center;">Número de reservas por espacio</h3>
            <canvas id="espacio_nreservas_chart" width="400" height="400"></canvas>
        </div>
        <div class="col-md-4">
            <h3 style="text-align:center;">Top 5 usuarios con mas reservas</h3>
            <canvas id="usuario_nreservas_chart" width="400" height="400"></canvas>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    function hora_volumen_transito_chart(){
        var horas = ["7:00-8:00","8:00-9:00","9:00-10:00","10:00-11:00","11:00-12:00","12:00-13:00","13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00","17:00-18:00","18:00-19:00","19:00-20:00","20:00-21:00","21:00-22:00"];
        var flujo_volumen_7_8 = JSON.parse("<?php echo e(json_encode($flujo_entrada_7_8)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_7_8)); ?>") ;
        var flujo_volumen_8_9 = JSON.parse("<?php echo e(json_encode($flujo_entrada_8_9)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_8_9)); ?>") ;
        var flujo_volumen_9_10 = JSON.parse("<?php echo e(json_encode($flujo_entrada_9_10)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_9_10)); ?>") ;
        var flujo_volumen_10_11 = JSON.parse("<?php echo e(json_encode($flujo_entrada_10_11)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_10_11)); ?>") ;
        var flujo_volumen_11_12 = JSON.parse("<?php echo e(json_encode($flujo_entrada_11_12)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_11_12)); ?>") ;
        var flujo_volumen_12_13 = JSON.parse("<?php echo e(json_encode($flujo_entrada_12_13)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_12_13)); ?>") ;
        var flujo_volumen_13_14 = JSON.parse("<?php echo e(json_encode($flujo_entrada_13_14)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_13_14)); ?>") ;
        var flujo_volumen_14_15 = JSON.parse("<?php echo e(json_encode($flujo_entrada_14_15)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_14_15)); ?>") ;
        var flujo_volumen_15_16 = JSON.parse("<?php echo e(json_encode($flujo_entrada_15_16)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_15_16)); ?>") ;
        var flujo_volumen_16_17 = JSON.parse("<?php echo e(json_encode($flujo_entrada_16_17)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_16_17)); ?>") ;
        var flujo_volumen_17_18 = JSON.parse("<?php echo e(json_encode($flujo_entrada_17_18)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_17_18)); ?>") ;
        var flujo_volumen_18_19 = JSON.parse("<?php echo e(json_encode($flujo_entrada_18_19)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_18_19)); ?>") ;
        var flujo_volumen_19_20 = JSON.parse("<?php echo e(json_encode($flujo_entrada_19_20)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_19_20)); ?>") ;
        var flujo_volumen_20_21 = JSON.parse("<?php echo e(json_encode($flujo_entrada_20_21)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_20_21)); ?>") ;
        var flujo_volumen_21_22 = JSON.parse("<?php echo e(json_encode($flujo_entrada_21_22)); ?>") + JSON.parse("<?php echo e(json_encode($flujo_salida_21_22)); ?>") ;
        var volumen = [flujo_volumen_7_8,flujo_volumen_8_9,flujo_volumen_9_10,flujo_volumen_10_11,
        flujo_volumen_11_12,flujo_volumen_12_13,flujo_volumen_13_14,flujo_volumen_14_15,flujo_volumen_15_16,flujo_volumen_16_17,
        flujo_volumen_17_18,flujo_volumen_18_19,flujo_volumen_19_20, flujo_volumen_20_21,flujo_volumen_21_22];
        
        var ctx = document.getElementById('hora_volumen_transito_chart').getContext('2d');
                    var hora_volumen_transito_chart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: horas,
                            datasets: [{
                                label: 'Volumen de tránsito <?php echo e($ayer); ?> ',
                                data: volumen,
                                backgroundColor: [
                                'rgb(9,7,57)',
                                'rgb(54, 162, 235)',
                                '#B67717',
                                '#094E1E',
                                '#96240D',
                                '#922B21',
                                '#76448A',
                                '#1F618D',
                                '#239B56',
                                '#B7950B ',
                                '#B9770E',
                                '#A04000',
                                '#B3B6B7',
                                '#616A6B ',
                                '#283747 '
                                ],
                                hoverOffset: 4
                            }]
                        },
                        options: {
                            indexAxis: 'y',
                            scales: {
                                y: {
                                    beginAtZero: true
                                    
                                }
                            },
                            ticks: {
                                precision: 0
                            }
                            

                        }
                    });

        }
    function hora_numero_espacios_disponibles_chart(){
        var horas = ["7:00-8:00","8:00-9:00","9:00-10:00","10:00-11:00","11:00-12:00","12:00-13:00","13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00","17:00-18:00","18:00-19:00","19:00-20:00","20:00-21:00","21:00-22:00"];
        var numero_espacios_disponibles_7_8 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_7_8)); ?>")
        var numero_espacios_disponibles_8_9 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_8_9)); ?>")
        var numero_espacios_disponibles_9_10 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_9_10)); ?>")
        var numero_espacios_disponibles_10_11 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_10_11)); ?>")
        var numero_espacios_disponibles_11_12 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_11_12)); ?>")
        var numero_espacios_disponibles_12_13 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_12_13)); ?>")
        var numero_espacios_disponibles_13_14 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_13_14)); ?>")
        var numero_espacios_disponibles_14_15 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_14_15)); ?>")
        var numero_espacios_disponibles_15_16 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_15_16)); ?>")
        var numero_espacios_disponibles_16_17 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_16_17)); ?>")
        var numero_espacios_disponibles_17_18 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_17_18)); ?>")
        var numero_espacios_disponibles_18_19 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_18_19)); ?>")
        var numero_espacios_disponibles_19_20 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_19_20)); ?>")
        var numero_espacios_disponibles_20_21 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_20_21)); ?>")
        var numero_espacios_disponibles_21_22 = JSON.parse("<?php echo e(json_encode($numero_espacios_disponibles_21_22)); ?>")
        console.log(numero_espacios_disponibles_9_10);
        var numero_espacios_disponibles = [numero_espacios_disponibles_7_8,numero_espacios_disponibles_8_9,numero_espacios_disponibles_9_10,numero_espacios_disponibles_10_11,
        numero_espacios_disponibles_11_12,numero_espacios_disponibles_12_13,numero_espacios_disponibles_13_14,numero_espacios_disponibles_14_15,numero_espacios_disponibles_15_16,numero_espacios_disponibles_16_17,
        numero_espacios_disponibles_17_18,numero_espacios_disponibles_18_19,numero_espacios_disponibles_19_20,numero_espacios_disponibles_20_21,numero_espacios_disponibles_21_22];
        var ctx = document.getElementById('hora_numero_espacios_disponibles_chart').getContext('2d');
                    var hora_numero_espacios_disponibles_chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: horas,
                            datasets: [{
                                label: 'Número de espacios disponibles <?php echo e($ayer); ?> ',
                                data: numero_espacios_disponibles,
                                backgroundColor: [
                                'rgb(9,7,57)',
                                'rgb(54, 162, 235)',
                                '#B67717',
                                '#094E1E',
                                '#96240D',
                                '#922B21',
                                '#76448A',
                                '#1F618D',
                                '#239B56',
                                '#B7950B ',
                                '#B9770E',
                                '#A04000',
                                '#B3B6B7',
                                '#616A6B ',
                                '#283747 '

                                ],
                                hoverOffset: 4
                            }]
                        },
                        options: {
                            indexAxis: 'y',
                            scales: {
                                x: {
                                        beginAtZero: true
                                    }
                            }
                            
                        } });

        }
    function fecha_nreservas_chart(){
                var fechas = [];
                var nreservas = [];
                <?php $__currentLoopData = $graficas_fecha_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficafechanreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    fechas.push("<?php echo e($graficafechanreservas->fecha_reserva); ?>");
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $graficas_fecha_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficafechanreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    nreservas.push(<?php echo e($graficafechanreservas->totalreservas); ?>);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                var ctx = document.getElementById('fecha_nreservas_chart').getContext('2d');
        
                var fecha_nreservas_chart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: fechas,
                        datasets: [{
                            label: ['N° de reservas por fecha'],
                            data: nreservas,
                            backgroundColor: [
                                'rgb(9,7,57)',
                                'rgb(54, 162, 235)',
                                '#B67717',
                                '#094E1E',
                                '#96240D',
                                '#922B21',
                                '#76448A',
                                '#1F618D',
                                '#239B56',
                                '#B7950B ',
                                '#B9770E',
                                '#A04000',
                                '#B3B6B7',
                                '#616A6B ',
                                '#283747 '
                            ],
                            borderColor: [
                                
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
                }
    function espacio_nreservas_chart(){
                    var espacios = [];
                    var nreservas = [];
                    <?php $__currentLoopData = $graficas_espacio_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficaespacionreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        espacios.push("<?php echo e($graficaespacionreservas->nomespacio); ?>");
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $graficas_espacio_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficaespacionreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        nreservas.push(<?php echo e($graficaespacionreservas->totalreservas); ?>);
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    var ctx = document.getElementById('espacio_nreservas_chart').getContext('2d');
                    var espacio_nreservas_chart = new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: espacios,
                            datasets: [{
                                label: 'My First Dataset',
                                data: nreservas,
                                backgroundColor: [
                                    'rgb(9,7,57)',
                                'rgb(54, 162, 235)',
                                '#B67717',
                                '#094E1E',
                                '#96240D',
                                '#922B21',
                                '#76448A',
                                '#1F618D',
                                '#239B56',
                                '#B7950B ',
                                '#B9770E',
                                '#A04000',
                                '#B3B6B7',
                                '#616A6B ',
                                '#283747 '
                                ],
                                hoverOffset: 4
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                }
    function usuario_nreservas_chart(){
                var usuarios=[];
                var nreservas=[];
                <?php $__currentLoopData = $graficas_usuario_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficausuarionreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        usuarios.push("<?php echo e($graficausuarionreservas->nombrecompleto); ?>");
                        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $graficas_usuario_nreservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graficausuarionreservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        nreservas.push(<?php echo e($graficausuarionreservas->totalreservas); ?>);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                var ctx = document.getElementById('usuario_nreservas_chart').getContext('2d');
                var usuario_nreservas_chart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: usuarios,
                        datasets: [{
                            label: '#5 usuarios con más reservas',
                            data: nreservas,
                            backgroundColor: [
                                'rgb(9,7,57)',
                                'rgb(54, 162, 235)',
                                '#B67717',
                                '#094E1E',
                                '#96240D',
                                '#922B21',
                                '#76448A',
                                '#1F618D',
                                '#239B56',
                                '#B7950B ',
                                '#B9770E',
                                '#A04000',
                                '#B3B6B7',
                                '#616A6B ',
                                '#283747 '
                            ],
                            borderColor: [
                                
                            ],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
    usuario_nreservas_chart();
    fecha_nreservas_chart();
    espacio_nreservas_chart();
    hora_volumen_transito_chart();
    hora_numero_espacios_disponibles_chart();
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\proyecto-parking\resources\views/admin/indicadores.blade.php ENDPATH**/ ?>