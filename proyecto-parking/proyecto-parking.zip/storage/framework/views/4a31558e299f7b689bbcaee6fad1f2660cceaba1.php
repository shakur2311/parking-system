

<?php $__env->startSection('content'); ?>
<div class="form-box shadow" style="padding:30px; width:40%;margin:auto;margin-top:200px; background:#fff; border-radius:5px;">
    <form action="login" method="POST">
        <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Correo electrónico</label>
            <div class="input-group flex-nowrap" >
                <span class="input-group-text" id="addon-wrapping">@</span>
                <input type="email" class="form-control" id="email" name="email"  aria-describedby="emailHelp">
            </div>  
            <div id="emailHelp" class="form-text">No compartas tus datos con nadie más.</div>
        </div>

        <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Contraseña</label>
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping">$</span>
                <input type="password" class="form-control" id="password" name="password">
            </div>  
        </div>
        <div class="mb-3">
            <button type="submit" class="btn btn-primary" style="width:100%;">Ingresar</button>
        </div>
        

        
    </form>
    <div class="form-box-footer" style="display:Flex; justify-content:space-around;">
        <a href="">Olvidaste tu contraseña?</a>
        <a href="register">Regístrate</a>
    </div>
    
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('connect.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\proyecto-laravel\resources\views/connect/login.blade.php ENDPATH**/ ?>