
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        table{
            border: 3px solid #FF7D61;
            background:#FF7D61;
            border-radius:5px;

        }
        thead{
            background:#76E1F6 ;
        }
    </style>
</head>
<body>
    <h2 style="color:#FF7D61;">Lista de vehículos registrados</h2>
    <table style="width:100%;">
        <thead>
            <tr>
                <td>Id</td>
                <td>Placa</td>
                <td>Propietario</td>
                <td>Marca</td>
                <td>Color</td>
            </tr>

        </thead>
        <tbody>
            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vehiculo->id_veh); ?></td>
                <td><?php echo e($vehiculo->placa_veh); ?></td>
                <td><?php echo e($vehiculo->name); ?> <?php echo e($vehiculo->lastname); ?></td>
                <td><?php echo e($vehiculo->marca_veh); ?></td>
                <td><?php echo e($vehiculo->color_veh); ?></td>
                    
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH D:\xamp\htdocs\proyecto-parking\resources\views/admin/tablavehiculos.blade.php ENDPATH**/ ?>