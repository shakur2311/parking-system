<table class="table table-striped" id="tableReservas">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Espacio</th>
        <th scope="col">Usuario</th>
        <th scope="col">Vehiculo</th>
        <th scope="col">fecha de reserva</th>
        <th scope="col">Hora de ingreso</th>
        <th scope="col">Hora de salida</th>
        <th scope="col">Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resultadosFiltrar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadoFiltrar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
            <th scope="row"><?php echo e($resultadoFiltrar->idreserva); ?></th>
            
            <td><?php echo e($resultadoFiltrar->nomespacio); ?></td>
            <td><?php echo e($resultadoFiltrar->nomusuario); ?></td>
            <td><?php echo e($resultadoFiltrar->nomvehiculo); ?></td>
            <td><?php echo e($resultadoFiltrar->fecha_reserva); ?></td>
            <td><?php echo e($resultadoFiltrar->fecha_ingreso); ?></td>
            <td><?php echo e($resultadoFiltrar->fecha_salida); ?></td>
            <?php if($resultadoFiltrar->estado=='1'): ?>
                <td><p style="padding:10px; background-color: #094E1E; width:100px; color:#fff; text-align:center; border-radius:5px;">En curso</p></td>
            <?php else: ?>
                <td><p style="padding:10px; background-color:#96240D; width:100px; color:#fff; text-align:center; border-radius:5px;">Terminado</p></td>
            <?php endif; ?>
            
        
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </tbody>
    </table>  <?php /**PATH D:\xamp\htdocs\proyecto-parking\resources\views/admin/tablafiltrarreservas.blade.php ENDPATH**/ ?>