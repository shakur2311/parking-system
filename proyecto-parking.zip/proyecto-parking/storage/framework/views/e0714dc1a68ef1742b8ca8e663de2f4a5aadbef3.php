
<?php $__env->startSection('content'); ?>
<div class="form-box shadow" style="padding:30px; width:40%;margin:auto;margin-top:200px; background:#fff; border-radius:5px;">
    <form action="register" method="POST">
         <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
        <div class="mb-3">
            <label for="name" class="form-label">Nombres</label>
            <div class="input-group flex-nowrap" >
                <span class="input-group-text" id="addon-wrapping">@</span>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>  
        </div>

        <div class="mb-3">
            <label for="lastname" class="form-label">Apellidos</label>
            <div class="input-group flex-nowrap" >
                <span class="input-group-text" id="addon-wrapping">@</span>
                <input type="text" class="form-control" id="lastname" name="lastname" required>
            </div>  
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <div class="input-group flex-nowrap" >
                <span class="input-group-text" id="addon-wrapping">@</span>
                <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" required>
            </div>  
        </div>

        <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping">$</span>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>  
        </div>

        <div class="mb-3">
        <label for="cpassword" class="form-label">Confirmar Contraseña</label>
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping">$</span>
                <input type="password" class="form-control" id="cpassword" name="cpassword" required>
            </div>  
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary" style="width:100%;">Registrarse</button>
        </div>
        

        
    </form>
    <div class="form-box-footer" style="display:Flex; justify-content:center;">
        <a href="login">Ya tienes cuenta?, ingresa</a>
        
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('connect.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\proyecto-laravel\resources\views/connect/register.blade.php ENDPATH**/ ?>